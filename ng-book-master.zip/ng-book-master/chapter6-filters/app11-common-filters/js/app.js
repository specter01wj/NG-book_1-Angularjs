var app = angular.module("myApp", [])
.controller('FiltersController',
['$scope', function($scope) {
  $scope.today = 1288323623006;
}]);