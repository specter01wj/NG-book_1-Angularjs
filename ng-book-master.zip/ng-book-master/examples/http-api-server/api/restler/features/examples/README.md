# examples
### Expected features for Live Examples

For Behavior Driven Development (BDD) we are using Behat to write down the
features and test them against the API

To run the tests just for examples (`public/examples`), run the following using the terminal from
the project root (where the vendor folder resides)

    bin/behat features/examples

> **Note:-** This requires the dependencies for restler framework to be
> installed